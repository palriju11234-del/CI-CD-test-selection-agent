import React from 'react';
import Hero from '../components/Hero.jsx';
import HowItWorks from '../components/HowItWorks.jsx';
import Features from '../components/Features.jsx';
import Docs from '../components/Docs.jsx';
import Login from '../components/Login.jsx';

export default function Home() {
  return (
    <main>
      <Hero />
      <HowItWorks />
      <Features />
      <Docs />
      <Login />
    </main>
  );
}
