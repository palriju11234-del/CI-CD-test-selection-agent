import React from 'react';

export default function FeatureCard({ icon, title, description }) {
  return (
    <article className="relative w-full max-w-[240px] xl:w-[213px] min-h-[213px] bg-tm-card border-2 border-black/20 rounded-[14px] p-5 flex flex-col items-center text-center feature-card-shadow hover:-translate-y-1 transition-transform duration-200 group">
      {/* Icon */}
      <div className="w-14 h-14 flex items-center justify-center mb-4">
        <img src={icon} alt="" className="w-10 h-10 object-contain group-hover:scale-110 transition-transform duration-200" />
      </div>

      {/* Feature Title */}
      <h3 className="font-inter font-semibold text-[14px] text-tm-orange mb-2 leading-tight">
        {title}
      </h3>

      {/* Description */}
      <p className="font-inter font-normal text-[13px] leading-snug text-black/65 max-w-[155px]">
        {description}
      </p>
    </article>
  );
}
