import React from 'react';

export default function Docs() {
  const steps = [
    {
      num: '1',
      title: 'Repository',
      subtitle: 'Connect GitHub / GitLab',
    },
    {
      num: '2',
      title: 'Analysis',
      subtitle: 'Detect changed code & dependencies',
    },
    {
      num: '3',
      title: 'Execution',
      subtitle: 'Run only relevant tests',
    },
  ];

  return (
    <section 
      id="docs" 
      className="relative w-full py-20 lg:py-28 overflow-hidden"
      style={{
        background: 'linear-gradient(120deg, #DAD7D7 0%, #FFFFFF 100%)'
      }}
    >
      <div className="max-w-[1290px] mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Text */}
          <div>
            <p className="text-tm-orange font-semibold text-[13px] tracking-[0.16em] uppercase mb-3">
              DOCUMENTATION
            </p>
            <h2 className="font-inter text-[36px] sm:text-[42px] xl:text-[46px] text-black font-normal leading-[1.1] mb-6">
              Connect your repository.<br />Let Test-Mind handle the selection.
            </h2>
            <p className="font-inter font-light text-[17px] sm:text-[18px] text-black/75 leading-relaxed max-w-[540px]">
              Start with a GitHub webhook, inspect the selected test set, and plug the result into your existing CI pipeline.
            </p>
          </div>

          {/* Right Panel Cards */}
          <div className="flex flex-col gap-4 max-w-[500px] w-full">
            {steps.map((step) => (
              <div 
                key={step.num}
                className="grid grid-cols-[44px_1fr] gap-4 items-center p-5 rounded-[15px] bg-tm-card shadow-[inset_0_0_15px_rgba(0,0,0,0.14)] hover:shadow-[inset_0_0_20px_rgba(0,0,0,0.2)] transition-shadow"
              >
                <div className="w-[36px] h-[36px] rounded-full border border-black flex items-center justify-center font-inter font-medium text-[16px] text-black">
                  {step.num}
                </div>
                <div>
                  <b className="block text-[16px] text-tm-orange font-semibold">
                    {step.title}
                  </b>
                  <span className="block text-[14px] text-black/60 mt-0.5">
                    {step.subtitle}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
