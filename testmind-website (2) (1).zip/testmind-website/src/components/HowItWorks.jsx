import React from 'react';
import ProcessCard from './ProcessCard.jsx';

import codePushIcon from '../assets/icons/code-push.svg';
import githubWebhookIcon from '../assets/icons/github-webhook.svg';
import aiAnalysisIcon from '../assets/icons/ai-analysis.svg';
import selectTestIcon from '../assets/icons/select-test.svg';
import runCiIcon from '../assets/icons/run-ci.svg';

export default function HowItWorks() {
  const steps = [
    {
      title: 'Code Push',
      description: 'Developer pushes\ncode or creates a\npull request',
      icon: codePushIcon,
    },
    {
      title: 'GitHub Webhook',
      description: 'Triggers the\nTest-Mind\nagent',
      icon: githubWebhookIcon,
    },
    {
      title: 'AI Analysis',
      description: '-Changes files\n-Dependencies\n-Historic CI data',
      icon: aiAnalysisIcon,
    },
    {
      title: 'Select Relevant Test',
      description: 'Predicts and selects\nonly the necessary\ntests',
      icon: selectTestIcon,
    },
    {
      title: 'Run in CI',
      description: 'Executes selected\ntests via GitHub\naction',
      icon: runCiIcon,
    },
  ];

  return (
    <section 
      id="how-it-works" 
      className="relative w-full py-20 lg:py-28 overflow-hidden"
      style={{
        background: 'linear-gradient(121deg, #DAD7D7 0%, #FFFFFF 76%)'
      }}
    >
      {/* Decorative radial glow */}
      <div 
        className="absolute -bottom-24 -left-20 w-[370px] h-[370px] rounded-full pointer-events-none opacity-40"
        style={{
          background: 'radial-gradient(circle, rgba(211,92,7,0.35) 0%, rgba(211,92,7,0) 70%)'
        }}
        aria-hidden="true"
      />

      <div className="max-w-[1320px] mx-auto px-6 relative z-10">
        {/* Section Heading */}
        <div className="text-center mb-14 lg:mb-20">
          <h2 className="font-inter font-normal text-[40px] sm:text-[50px] lg:text-[64px] text-black tracking-tight leading-tight mb-3">
            How It Works?
          </h2>
          <p className="font-inter font-normal text-[18px] sm:text-[20px] text-tm-orange">
            From code change to test results all automated
          </p>
        </div>

        {/* 5-Step Pipeline Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-6 xl:gap-8 justify-items-center max-w-[1240px] mx-auto">
          {steps.map((step, idx) => (
            <ProcessCard
              key={step.title}
              title={step.title}
              description={step.description}
              icon={step.icon}
              stepNumber={idx + 1}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
