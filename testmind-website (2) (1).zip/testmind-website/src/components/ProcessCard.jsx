import React from 'react';

export default function ProcessCard({ icon, title, description, stepNumber }) {
  return (
    <article className="relative w-full max-w-[220px] xl:w-[190px] min-h-[190px] bg-tm-card rounded-[10px] p-5 flex flex-col items-center text-center shadow-[inset_0_0_0_1px_rgba(0,0,0,0.06)] hover:-translate-y-1 transition-transform duration-200 group">
      {/* Icon */}
      <div className="w-12 h-12 flex items-center justify-center mb-3">
        <img src={icon} alt="" className="w-9 h-9 object-contain group-hover:scale-110 transition-transform duration-200" />
      </div>

      {/* Step Title */}
      <h3 className="font-inter font-semibold text-[15px] text-tm-orange mb-2 leading-tight">
        {title}
      </h3>

      {/* Description */}
      <p className="font-inter font-normal text-[12px] leading-snug text-black/65 whitespace-pre-line mb-6">
        {description}
      </p>

      {/* Diagonal Arrow Circle */}
      <div className="absolute right-2 bottom-2 w-8 h-8 rounded-full border border-black/80 flex items-center justify-center text-[16px] text-black font-medium group-hover:bg-tm-orange group-hover:text-white group-hover:border-tm-orange transition-colors">
        ↗
      </div>
    </article>
  );
}
