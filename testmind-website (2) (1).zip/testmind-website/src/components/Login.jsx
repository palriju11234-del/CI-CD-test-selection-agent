import React from 'react';

export default function Login() {
  return (
    <section 
      id="login" 
      className="relative w-full py-24 lg:py-32 bg-[#F5F5F5] flex items-center justify-center px-6"
    >
      <div className="max-w-[700px] w-full text-center px-8 py-14 sm:px-16 sm:py-16 rounded-[28px] bg-tm-card shadow-[inset_0_0_25px_rgba(0,0,0,0.15),0_20px_50px_rgba(0,0,0,0.1)]">
        <p className="text-tm-orange font-semibold text-[13px] tracking-[0.16em] uppercase mb-3">
          TEST-MIND
        </p>
        <h2 className="font-inter text-[34px] sm:text-[44px] text-black font-normal leading-tight mb-4">
          Ready to make CI faster?
        </h2>
        <p className="font-inter font-light text-[16px] sm:text-[18px] text-black/70 leading-relaxed mb-8 max-w-[500px] mx-auto">
          Start accelerating your continuous integration with intelligent test selection. Connect this CTA to your authentication flow or get started today.
        </p>
        <div className="flex justify-center">
          <a
            href="mailto:hello@test-mind.local"
            className="btn-get-started inline-flex items-center justify-center px-10 h-[64px] rounded-[50px] font-inter font-medium text-[20px] text-black tracking-normal no-underline hover:scale-[1.02] transition-transform"
          >
            Contact / Login
          </a>
        </div>
      </div>
    </section>
  );
}
