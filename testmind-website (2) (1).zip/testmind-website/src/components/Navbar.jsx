import React, { useState, useEffect } from 'react';

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'how-it-works', 'features', 'docs', 'login'];
      const scrollPosition = window.scrollY + 120;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'How it works', href: '#how-it-works', id: 'how-it-works' },
    { label: 'Features', href: '#features', id: 'features' },
    { label: 'Docs', href: '#docs', id: 'docs' },
    { label: 'Login', href: '#login', id: 'login' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#F5F5F5]/80 backdrop-blur-md transition-all duration-300">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-16 h-[72px] lg:h-[88px] flex items-center justify-between">
        {/* Brand Logo visible on tablet/mobile or subtle on desktop */}
        <a 
          href="#home" 
          className="font-orbitron font-extrabold text-xl lg:text-2xl text-gradient-orbitron tracking-tight hover:opacity-90 transition-opacity"
        >
          TEST-MIND
        </a>

        {/* Desktop Navigation matching Figma spacing & typography */}
        <nav className="hidden md:flex items-center gap-10 lg:gap-16 xl:gap-24 font-inter text-[18px] lg:text-[20px] font-light text-black">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className={`relative py-1 transition-colors duration-200 hover:text-tm-orange ${
                activeSection === item.id ? 'text-tm-orange font-normal' : 'text-black'
              }`}
            >
              {item.label}
              {activeSection === item.id && (
                <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-tm-orange rounded-full animate-fade-in" />
              )}
            </a>
          ))}
        </nav>

        {/* Mobile Hamburger Button */}
        <button
          type="button"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-black hover:text-tm-orange focus:outline-none"
          aria-label="Toggle navigation menu"
        >
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {mobileMenuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#F5F5F5] border-b border-black/10 px-6 py-6 shadow-xl animate-in slide-in-from-top">
          <nav className="flex flex-col gap-4 font-inter text-lg font-light text-black">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`py-2 px-3 rounded-lg transition-colors ${
                  activeSection === item.id ? 'text-tm-orange bg-orange-50 font-medium' : 'hover:text-tm-orange'
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
