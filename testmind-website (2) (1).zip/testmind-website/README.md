# TEST-MIND Website (React + Vite + Tailwind CSS)

This is a modern, high-fidelity React application implementing the Test-Mind Figma design.

## Features
- **Hero Section**: Exact 1440×900 desktop composition featuring the human hand, robotic arm, Test-Mind robot, and ambient glow, with full responsive adaptations.
- **How It Works**: 5-step automated pipeline process cards with Figma vector icons and diagonal action indicators.
- **Features**: Split banner layout with 5 distinct feature cards highlighting intelligent test selection capabilities.
- **Documentation**: Onboarding documentation walkthrough with numbered step cards.
- **Login CTA**: Conversion card leading to contact/auth flow.
- **Smooth Navigation**: Desktop and mobile navigation with active section indicator and responsive hamburger menu.

## Tech Stack
- **Framework**: React 18 + Vite
- **Styling**: Tailwind CSS + Custom CSS Design Tokens
- **Typography**: Google Fonts (Inter & Orbitron)

## Getting Started

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Run Development Server**:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

3. **Production Build**:
   ```bash
   npm run build
   ```
